function sayHello(){
    document.body.innerHTML = "hello world";
}

export {sayHello}