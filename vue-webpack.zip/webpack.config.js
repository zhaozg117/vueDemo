const path = require('path')
const webpack = require('webpack')
const HtmlWebpackPlugin = require('html-webpack-plugin');
const VueLoaderPlugin = require('vue-loader/lib/plugin');
const {
    CleanWebpackPlugin
} = require('clean-webpack-plugin');

module.exports = {
    entry: {
        app: './src/main.js'
    },
    output: {
        path: path.resolve(__dirname, './dist'), // 项目的打包文件路径
        publicPath: '/', // 通过devServer访问路径
        filename: '[name].[hash].js',
        // filename: 'bundle.js',
        chunkFilename: '[id].[chunkhash].js'
    },
    mode: 'development',
    resolve: {
        // require时省略的扩展名，遇到.vue结尾的也要去加载
        // extensions: ['.js', '.vue', '.json'],
        extensions: ['*', '.js', '.vue', '.json'],
        // 模块别名地址，方便后续直接引用别名，无须写长长的地址，注意如果后续不能识别该别名，需要先设置root
        alias: {
            'vue$': 'vue/dist/vue.esm.js',
            '@': path.join(__dirname, 'src')
        }
    },

    devServer: {
        host: 'localhost',
        port: '8081',
        contentBase: './dist'
    },

    // 不进行打包的模块
    // externals: {},

    module: {
        rules: [{
                test: /\.js$/,
                exclude: /node_modules/,
                loader: "babel-loader"
            },
            {
                test: /\.vue$/,
                use: ['vue-loader']
            },
            // {
            //     test: /\.css$/,
            //     use: ['css-loader', 'vue-style-loader']
            // }, {
            //     test: /\.less$/,
            //     use: ['css-loader', 'vue-style-loader', 'less-loader']
            // },
            {
                test: /\.less$/,
                use:[
                    "style-loader",
                    {loader: "css-loader",options:{sourceMap: true, importLoaders: 1}},
                    // "postcss-loader",
                    "less-loader"
                ]
              },
              {
                test: /\.css$/,
                use:[
                    "style-loader",
                    {loader: "css-loader",options:{sourceMap: true, importLoaders: 1}},
                    // "postcss-loader"
                ]
              },
        ]

    },
    plugins: [new CleanWebpackPlugin(),
        new HtmlWebpackPlugin({
            template: 'index.html',
            // template: './index.html'
        }),
        new VueLoaderPlugin()
    ]
};